/* -------------------------------------------------- */

/*  Start of Webpack Chrome Hot Extension Middleware  */

/* ================================================== */

/*  This will be converted into a lodash templ., any  */

/*  external argument must be provided using it       */

/* -------------------------------------------------- */
(function (chrome, window) {
  var signals = JSON.parse('{"SIGN_CHANGE":"SIGN_CHANGE","SIGN_RELOAD":"SIGN_RELOAD","SIGN_RELOADED":"SIGN_RELOADED","SIGN_LOG":"SIGN_LOG","SIGN_CONNECT":"SIGN_CONNECT"}');
  var config = JSON.parse('{"RECONNECT_INTERVAL":2000,"SOCKET_ERR_CODE_REF":"https://tools.ietf.org/html/rfc6455#section-7.4.1"}');
  var reloadPage = "false" === "true";
  var wsHost = "ws://localhost:9090";
  var SIGN_CHANGE = signals.SIGN_CHANGE,
      SIGN_RELOAD = signals.SIGN_RELOAD,
      SIGN_RELOADED = signals.SIGN_RELOADED,
      SIGN_LOG = signals.SIGN_LOG,
      SIGN_CONNECT = signals.SIGN_CONNECT;
  var RECONNECT_INTERVAL = config.RECONNECT_INTERVAL,
      SOCKET_ERR_CODE_REF = config.SOCKET_ERR_CODE_REF;
  var runtime = chrome.runtime,
      tabs = chrome.tabs;
  var manifest = runtime.getManifest(); // =============================== Helper functions ======================================= //

  var formatter = function formatter(msg) {
    return "[ WCER: ".concat(msg, " ]");
  };

  var logger = function logger(msg) {
    var level = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "info";
    return console[level](formatter(msg));
  };

  var timeFormatter = function timeFormatter(date) {
    return date.toTimeString().replace(/.*(\d{2}:\d{2}:\d{2}).*/, "$1");
  }; // ========================== Called only on content scripts ============================== //


  function contentScriptWorker() {
    runtime.sendMessage({
      type: SIGN_CONNECT
    }, function (msg) {
      return console.info(msg);
    });
    runtime.onMessage.addListener(function (_ref) {
      var type = _ref.type,
          payload = _ref.payload;

      switch (type) {
        case SIGN_RELOAD:
          logger("Detected Changes. Reloading ...");
          reloadPage && window.location.reload();
          break;

        case SIGN_LOG:
          console.info(payload);
          break;
      }
    });
  } // ======================== Called only on background scripts ============================= //


  function backgroundWorker(socket) {
    runtime.onMessage.addListener(function (action, sender, sendResponse) {
      if (action.type === SIGN_CONNECT) {
        sendResponse(formatter("Connected to Chrome Extension Hot Reloader"));
      }
    });
    socket.addEventListener("message", function (_ref2) {
      var data = _ref2.data;

      var _JSON$parse = JSON.parse(data),
          type = _JSON$parse.type,
          payload = _JSON$parse.payload;

      if (type === SIGN_CHANGE) {
        tabs.query({
          status: "complete"
        }, function (loadedTabs) {
          loadedTabs.forEach(function (tab) {
            return tab.id && tabs.sendMessage(tab.id, {
              type: SIGN_RELOAD
            });
          });
          socket.send(JSON.stringify({
            type: SIGN_RELOADED,
            payload: formatter("".concat(timeFormatter(new Date()), " - ").concat(manifest.name, " successfully reloaded"))
          }));
          runtime.reload();
        });
      } else {
        runtime.sendMessage({
          type: type,
          payload: payload
        });
      }
    });
    socket.addEventListener("close", function (_ref3) {
      var code = _ref3.code;
      logger("Socket connection closed. Code ".concat(code, ". See more in ").concat(SOCKET_ERR_CODE_REF), "warn");
      var intId = setInterval(function () {
        logger("Attempting to reconnect (tip: Check if Webpack is running)");
        var ws = new WebSocket(wsHost);
        ws.addEventListener("open", function () {
          clearInterval(intId);
          logger("Reconnected. Reloading plugin");
          runtime.reload();
        });
      }, RECONNECT_INTERVAL);
    });
  } // ======================= Bootstraps the middleware =========================== //


  runtime.reload ? backgroundWorker(new WebSocket(wsHost)) : contentScriptWorker();
})(chrome, window);
/* ----------------------------------------------- */

/* End of Webpack Chrome Hot Extension Middleware  */

/* ----------------------------------------------- *//******/ (function(modules) { // webpackBootstrap
/******/ 	// install a JSONP callback for chunk loading
/******/ 	function webpackJsonpCallback(data) {
/******/ 		var chunkIds = data[0];
/******/ 		var moreModules = data[1];
/******/ 		var executeModules = data[2];
/******/
/******/ 		// add "moreModules" to the modules object,
/******/ 		// then flag all "chunkIds" as loaded and fire callback
/******/ 		var moduleId, chunkId, i = 0, resolves = [];
/******/ 		for(;i < chunkIds.length; i++) {
/******/ 			chunkId = chunkIds[i];
/******/ 			if(Object.prototype.hasOwnProperty.call(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 				resolves.push(installedChunks[chunkId][0]);
/******/ 			}
/******/ 			installedChunks[chunkId] = 0;
/******/ 		}
/******/ 		for(moduleId in moreModules) {
/******/ 			if(Object.prototype.hasOwnProperty.call(moreModules, moduleId)) {
/******/ 				modules[moduleId] = moreModules[moduleId];
/******/ 			}
/******/ 		}
/******/ 		if(parentJsonpFunction) parentJsonpFunction(data);
/******/
/******/ 		while(resolves.length) {
/******/ 			resolves.shift()();
/******/ 		}
/******/
/******/ 		// add entry modules from loaded chunk to deferred list
/******/ 		deferredModules.push.apply(deferredModules, executeModules || []);
/******/
/******/ 		// run deferred modules when all chunks ready
/******/ 		return checkDeferredModules();
/******/ 	};
/******/ 	function checkDeferredModules() {
/******/ 		var result;
/******/ 		for(var i = 0; i < deferredModules.length; i++) {
/******/ 			var deferredModule = deferredModules[i];
/******/ 			var fulfilled = true;
/******/ 			for(var j = 1; j < deferredModule.length; j++) {
/******/ 				var depId = deferredModule[j];
/******/ 				if(installedChunks[depId] !== 0) fulfilled = false;
/******/ 			}
/******/ 			if(fulfilled) {
/******/ 				deferredModules.splice(i--, 1);
/******/ 				result = __webpack_require__(__webpack_require__.s = deferredModule[0]);
/******/ 			}
/******/ 		}
/******/
/******/ 		return result;
/******/ 	}
/******/
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// object to store loaded and loading chunks
/******/ 	// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 	// Promise = chunk loading, 0 = chunk loaded
/******/ 	var installedChunks = {
/******/ 		"background": 0
/******/ 	};
/******/
/******/ 	var deferredModules = [];
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	var jsonpArray = window["webpackJsonp"] = window["webpackJsonp"] || [];
/******/ 	var oldJsonpFunction = jsonpArray.push.bind(jsonpArray);
/******/ 	jsonpArray.push = webpackJsonpCallback;
/******/ 	jsonpArray = jsonpArray.slice();
/******/ 	for(var i = 0; i < jsonpArray.length; i++) webpackJsonpCallback(jsonpArray[i]);
/******/ 	var parentJsonpFunction = oldJsonpFunction;
/******/
/******/
/******/ 	// add entry module to deferred list
/******/ 	deferredModules.push([11,"chunk-vendors","chunk-common"]);
/******/ 	// run deferred modules when ready
/******/ 	return checkDeferredModules();
/******/ })
/************************************************************************/
/******/ ({

/***/ "./src/background/app-state.ts":
/*!*************************************!*\
  !*** ./src/background/app-state.ts ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! events */ \"../../../node_modules/events/events.js\");\n/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_0__);\n\nconst IDLE_TIMEOUT = 60 * 1000;\n\nclass AppState extends events__WEBPACK_IMPORTED_MODULE_0__[\"EventEmitter\"] {\n  constructor() {\n    super();\n    this.state = '';\n    this.set('initial');\n  }\n  /**\n   * App states: initial -> active -> inactive -> idle\n   * Opening UI switches state to active. Closing UI switches state to inactive.\n   * After being inactive for a certain amount of time, switch to idle.\n   * @param {string} nextState\n   */\n\n\n  set(nextState) {\n    if (nextState != 'inactive') {\n      if (this.idleTimeout) {\n        clearTimeout(this.idleTimeout);\n      }\n    }\n\n    if (this.state != nextState && nextState == 'inactive') {\n      if (this.idleTimeout) {\n        clearTimeout(this.idleTimeout);\n      }\n\n      this.idleTimeout = setTimeout(() => {\n        console.log('idle timeout !! <- 60s');\n        this.set('idle');\n      }, IDLE_TIMEOUT);\n    }\n\n    if (this.state != nextState) {\n      console.log(`[state] ${this.state} -> ${nextState}`);\n    }\n\n    this.state = nextState;\n    this.emit('change', nextState);\n    this.emit(nextState);\n  }\n\n}\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (AppState);\n\n//# sourceURL=webpack:///./src/background/app-state.ts?");

/***/ }),

/***/ "./src/background/controller.ts":
/*!**************************************!*\
  !*** ./src/background/controller.ts ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.promise.js */ \"../../../node_modules/core-js/modules/es.promise.js\");\n/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ \"../../../node_modules/core-js/modules/es.error.cause.js\");\n/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! core-js/modules/es.array.iterator.js */ \"../../../node_modules/core-js/modules/es.array.iterator.js\");\n/* harmony import */ var core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_array_iterator_js__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! core-js/modules/web.dom-collections.iterator.js */ \"../../../node_modules/core-js/modules/web.dom-collections.iterator.js\");\n/* harmony import */ var core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_web_dom_collections_iterator_js__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! core-js/modules/es.regexp.to-string.js */ \"../../../node_modules/core-js/modules/es.regexp.to-string.js\");\n/* harmony import */ var core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_regexp_to_string_js__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var extensionizer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! extensionizer */ \"../../../node_modules/extensionizer/index.js\");\n/* harmony import */ var extensionizer__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(extensionizer__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! events */ \"../../../node_modules/events/events.js\");\n/* harmony import */ var events__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(events__WEBPACK_IMPORTED_MODULE_6__);\n/* harmony import */ var pump__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! pump */ \"../../../node_modules/pump/index.js\");\n/* harmony import */ var pump__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(pump__WEBPACK_IMPORTED_MODULE_7__);\n/* harmony import */ var dnode_browser_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! dnode/browser.js */ \"../../../node_modules/dnode/browser.js\");\n/* harmony import */ var dnode_browser_js__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(dnode_browser_js__WEBPACK_IMPORTED_MODULE_8__);\n/* harmony import */ var _ledgerhq_hw_transport_webusb__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @ledgerhq/hw-transport-webusb */ \"../../../node_modules/@ledgerhq/hw-transport-webusb/lib-es/TransportWebUSB.js\");\n/* harmony import */ var _herajs_wallet__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @herajs/wallet */ \"../../../node_modules/@herajs/wallet/dist/herajs-wallet.iife.js\");\n/* harmony import */ var _herajs_wallet__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_herajs_wallet__WEBPACK_IMPORTED_MODULE_10__);\n/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../config */ \"./src/config.ts\");\n/* harmony import */ var _store__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./store */ \"./src/background/store.ts\");\n/* harmony import */ var _tx_scanner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./tx-scanner */ \"./src/background/tx-scanner.ts\");\n/* harmony import */ var _api__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./api */ \"./src/background/api.ts\");\n/* harmony import */ var _app_state__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./app-state */ \"./src/background/app-state.ts\");\n/* harmony import */ var buffer__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! buffer */ \"../../../node_modules/node-libs-browser/node_modules/buffer/index.js\");\n/* harmony import */ var buffer__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(buffer__WEBPACK_IMPORTED_MODULE_16__);\n/* harmony import */ var _herajs_crypto__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! @herajs/crypto */ \"../../../node_modules/@herajs/crypto/dist/herajs-crypto.umd.js\");\n/* harmony import */ var _herajs_crypto__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_herajs_crypto__WEBPACK_IMPORTED_MODULE_17__);\n/* harmony import */ var _herajs_common__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! @herajs/common */ \"../../../node_modules/@herajs/common/dist/herajs-common.esm.js\");\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n //import 'whatwg-fetch';\n\n\n\n\n\nclass BackgroundController extends events__WEBPACK_IMPORTED_MODULE_6__[\"EventEmitter\"] {\n  constructor() {\n    var _this;\n\n    super();\n    _this = this;\n    this.id = extensionizer__WEBPACK_IMPORTED_MODULE_5___default.a.runtime.id;\n    this.requests = {};\n    this.lastRequestId = 0;\n    this.uiState = {\n      popupOpen: false\n    };\n    this.state = new _app_state__WEBPACK_IMPORTED_MODULE_15__[\"default\"]();\n    this.wallet = new _herajs_wallet__WEBPACK_IMPORTED_MODULE_10__[\"Wallet\"]({\n      appName: 'aergo-browser-wallet',\n      instanceId: this.id\n    });\n    this.wallet.use(_tx_scanner__WEBPACK_IMPORTED_MODULE_13__[\"AergoscanTransactionScanner\"]);\n    this.wallet.useStorage(_store__WEBPACK_IMPORTED_MODULE_12__[\"default\"]).then(async function () {\n      if (!_this.wallet.datastore) throw new Error('wallet failed to initiate storage');\n\n      _this.firstLoad(); // Load custom defined chains\n\n\n      try {\n        const customChains = await _this.wallet.datastore.getIndex('settings').get('customChains');\n        console.log(_this.wallet.datastore);\n\n        if (customChains && customChains.data) {\n          for (const chainId of Object.keys(customChains.data)) {\n            var _customChains$data$ch;\n\n            // @ts-ignore\n            _this.wallet.useChain({\n              chainId,\n              nodeUrl: (_customChains$data$ch = customChains.data[chainId]) === null || _customChains$data$ch === void 0 ? void 0 : _customChains$data$ch.toString()\n            });\n          }\n        }\n      } catch (e) {// not found\n      }\n    });\n\n    for (const chain of _config__WEBPACK_IMPORTED_MODULE_11__[\"default\"].ChainConfigs) {\n      this.wallet.useChain(chain);\n    }\n\n    this.wallet.keyManager.on('lock', () => {\n      this.emit('update', {\n        unlocked: false\n      });\n      console.log('[lock] locked');\n    });\n    this.wallet.keyManager.on('unlock', () => {\n      this.emit('update', {\n        unlocked: true\n      });\n      console.log('[lock] unlocked');\n    });\n    this.wallet.accountManager.on('remove', accountSpec => {\n      this.emit('update', {\n        accountsRemoved: [accountSpec]\n      });\n    }); // Background script cannot access USB device\n\n    this.wallet.keyManager.useExternalLedger = true; // On idle (60s after UI becoming inactive)\n\n    this.state.on('idle', () => {\n      this.lock();\n      console.log('[state] idle, pausing trackers');\n      this.wallet.accountManager.pause();\n      this.wallet.transactionManager.pause();\n    });\n    this.state.on('active', () => {\n      console.log('[state] active, resuming trackers');\n      this.wallet.accountManager.resume();\n      this.wallet.transactionManager.resume();\n    });\n    this.lock();\n  }\n\n  async firstLoad() {\n    const accounts = await this.wallet.accountManager.getAccounts();\n\n    for (const account of accounts) {\n      this.trackAccount(account);\n    }\n  }\n\n  lock() {\n    this.wallet.lock();\n  }\n\n  async unlock(passphrase) {\n    await this.wallet.unlock(passphrase);\n  }\n\n  async setupAndUnlock(passphrase) {\n    await this.wallet.setupAndUnlock(passphrase);\n  }\n\n  async setActiveAccount({\n    chainId,\n    address\n  }) {\n    const account = await this.wallet.accountManager.getOrAddAccount({\n      address,\n      chainId\n    });\n    this.activeAccount = account;\n  }\n\n  async getActiveAccount() {\n    return this.activeAccount;\n  }\n  /**\n   * Returns true if the UI is currently open.\n   * Currently unused, but can be used in the future to detect where notifications should be shown.\n   */\n\n\n  isUiOpen() {\n    return this.uiState.popupOpen;\n  }\n\n  trackAccount(account, onceCb) {\n    const accountTracker = this.wallet.accountManager.trackAccount(account);\n    this.wallet.transactionManager.trackAccount(account);\n    accountTracker.then(t => {\n      t.removeAllListeners('update');\n      t.on('update', account => {\n        this.emit('update', {\n          accounts: [account]\n        });\n\n        if (onceCb) {\n          onceCb(account);\n          onceCb = undefined;\n        }\n      }); // Force an initial load and update with data\n\n      t.load().then(account => {\n        this.emit('update', {\n          accounts: [account]\n        });\n      });\n    }); // Make an initial update (data might be empty)\n\n    this.emit('update', {\n      accounts: [account]\n    });\n  }\n\n  permissionRequest(request) {\n    const requestId = this.lastRequestId++;\n    this.requests[requestId] = request;\n    extensionizer__WEBPACK_IMPORTED_MODULE_5___default.a.windows.getCurrent(window => {\n      const left = Math.max(0, window.left + window.width - 360);\n      extensionizer__WEBPACK_IMPORTED_MODULE_5___default.a.windows.create({\n        // @ts-ignore\n        url: extensionizer__WEBPACK_IMPORTED_MODULE_5___default.a.runtime.getURL(`popup-request.html?request=${requestId}`),\n        type: 'popup',\n        width: 360,\n        height: 620,\n        top: window.top,\n        left\n      });\n    });\n  }\n\n  respondToPermissionRequest(requestId, result, respondCancel = false) {\n    const request = this.requests[requestId];\n    if (!request) return;\n\n    if (respondCancel) {\n      request.sendCancel({\n        error: 'user cancelled request'\n      });\n      return;\n    }\n\n    request.sendSuccess(result);\n  }\n\n  async signMessage({\n    address,\n    chainId,\n    message,\n    hash: msgHash\n  }) {\n    const account = await this.wallet.accountManager.getOrAddAccount({\n      address,\n      chainId\n    });\n    const signMessage = msgHash ? buffer__WEBPACK_IMPORTED_MODULE_16__[\"Buffer\"].from(msgHash) : Object(_herajs_crypto__WEBPACK_IMPORTED_MODULE_17__[\"hash\"])(buffer__WEBPACK_IMPORTED_MODULE_16__[\"Buffer\"].from(message));\n    return await this.wallet.keyManager.signMessage(account, signMessage);\n  }\n\n  async signTransaction({\n    address,\n    chainId,\n    txData\n  }) {\n    const account = await this.wallet.accountManager.getOrAddAccount({\n      address,\n      chainId\n    });\n    const preparedTxData = await this.wallet.accountManager.prepareTransaction(account, txData);\n    return await this.wallet.keyManager.signTransaction(account, preparedTxData);\n  }\n\n  async sendTransaction({\n    txBody,\n    chainId\n  }) {\n    const accountSpec = {\n      address: txBody.from,\n      chainId: chainId\n    };\n    let tx = txBody;\n\n    if (txBody.sign) {\n      // Externally pre-signed transaction\n      tx = await this.wallet.prepareTransaction(accountSpec, txBody);\n      tx.txBody.sign = txBody.sign;\n      tx.txBody.hash = await Object(_herajs_crypto__WEBPACK_IMPORTED_MODULE_17__[\"hashTransaction\"])(txBody, 'base58');\n    }\n\n    const txTracker = await this.wallet.sendTransaction(accountSpec, tx);\n    console.log(txTracker, txTracker.transaction.txBody);\n    txTracker.getReceipt().then(receipt => {\n      if (receipt.status === 'SUCCESS') {\n        this.handleConfirmedTx(txTracker.transaction);\n      }\n    });\n    return txTracker.transaction.txBody;\n  }\n  /**\n   * Handle confirmed transactions sent through the wallet\n   */\n\n\n  async handleConfirmedTx(transaction) {\n    if (!transaction.txBody) return; // Apply name transactions to internal db\n\n    if (transaction.txBody.type === _herajs_common__WEBPACK_IMPORTED_MODULE_18__[\"TxTypes\"].Governance && transaction.txBody.to === 'aergo.name') {\n      const client = this.wallet.getClient(transaction.data.chainId);\n      const blockhash = transaction.data.blockhash;\n      const block = await client.getBlockMetadata(blockhash);\n      const events = await client.getEvents({\n        address: 'aergo.name',\n        blockfrom: block.header.blockno,\n        blockto: block.header.blockno\n      });\n\n      for (const event of events) {\n        if (event.eventName === 'update name' || event.eventName === 'create name') {\n          //console.log('Handling name event...', event);\n          this.wallet.nameManager.updateName({\n            address: event.args[1] || transaction.data.from,\n            chainId: transaction.data.chainId\n          }, event.args[0]);\n        }\n      }\n    }\n  }\n\n  async connectLedger() {\n    if (this.wallet.ledger) return;\n    console.log('Connecting Ledger...');\n    const transport = await _ledgerhq_hw_transport_webusb__WEBPACK_IMPORTED_MODULE_9__[\"default\"].create(30000, 1500);\n    this.wallet.connectLedger(transport);\n  }\n\n  setupCommunication(outStream) {\n    const api = Object(_api__WEBPACK_IMPORTED_MODULE_14__[\"getServerApi\"])(this);\n    const dnode = dnode_browser_js__WEBPACK_IMPORTED_MODULE_8___default()(api);\n    pump__WEBPACK_IMPORTED_MODULE_7___default()(outStream, dnode, outStream, err => {\n      if (err) console.error(err);\n    });\n    dnode.on('remote', remote => {\n      const sendUpdate = remote.sendUpdate.bind(remote);\n      this.on('update', sendUpdate);\n    });\n    this.state.on('change', state => {\n      this.emit('update', {\n        state\n      });\n    });\n  }\n\n}\n\n/* harmony default export */ __webpack_exports__[\"default\"] = (BackgroundController);\n\n//# sourceURL=webpack:///./src/background/controller.ts?");

/***/ }),

/***/ "./src/background/main.js":
/*!********************************!*\
  !*** ./src/background/main.js ***!
  \********************************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.promise.js */ \"../../../node_modules/core-js/modules/es.promise.js\");\n/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! regenerator-runtime/runtime */ \"../../../node_modules/regenerator-runtime/runtime.js\");\n/* harmony import */ var regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(regenerator_runtime_runtime__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var extensionizer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! extensionizer */ \"../../../node_modules/extensionizer/index.js\");\n/* harmony import */ var extensionizer__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(extensionizer__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var end_of_stream__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! end-of-stream */ \"../../../node_modules/end-of-stream/index.js\");\n/* harmony import */ var end_of_stream__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(end_of_stream__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var extension_port_stream__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! extension-port-stream */ \"../../../node_modules/extension-port-stream/index.js\");\n/* harmony import */ var extension_port_stream__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(extension_port_stream__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _controller__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./controller */ \"./src/background/controller.ts\");\n/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./request */ \"./src/background/request.ts\");\n\n\n\n__webpack_require__(/*! ../manifest.json */ \"./src/manifest.json\");\n\n\n\n\n\n\n\nasync function setupController() {\n  const controller = new _controller__WEBPACK_IMPORTED_MODULE_5__[\"default\"]();\n\n  function connectRemote(remotePort) {\n    const processName = remotePort.name;\n    console.log('Establishing connection with', processName);\n\n    if (processName === 'external') {\n      remotePort.onMessage.addListener((msg, port) => {\n        const request = _request__WEBPACK_IMPORTED_MODULE_6__[\"ExternalRequest\"].fromPortMessage(port, msg);\n        controller.permissionRequest(request);\n      });\n    } else {\n      const portStream = new extension_port_stream__WEBPACK_IMPORTED_MODULE_4___default.a(remotePort);\n      controller.state.set('active');\n      controller.setupCommunication(portStream);\n      controller.uiState.popupOpen = true;\n      console.log(remotePort, 'port');\n      end_of_stream__WEBPACK_IMPORTED_MODULE_3___default()(portStream, () => {\n        controller.uiState.popupOpen = false;\n        console.log('Closed connection with', processName);\n        controller.state.set('inactive');\n      });\n    }\n  }\n\n  extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.runtime.onConnect.addListener(connectRemote); // Setup idle detection\n\n  extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.idle.setDetectionInterval(60);\n  extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.idle.onStateChanged.addListener(newState => {\n    console.log('idle onStateChanged : ' + newState);\n\n    if (newState === 'idle' || newState === 'locked') {\n      controller.lock();\n    }\n  });\n}\n\nconsole.log('AERGO Wallet Background Script');\nconsole.log('Extension ID', extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.runtime.id);\n\nif (!extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.runtime.id) {\n  console.error('Script needs run in extension context. Aborting');\n} else {\n  setupController();\n  extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.contextMenus.removeAll();\n  extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.contextMenus.create({\n    title: 'Open full page',\n    contexts: ['browser_action'],\n    onclick: function () {\n      extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.tabs.create({\n        url: 'index.html'\n      });\n    }\n  });\n  extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.contextMenus.create({\n    title: 'Settings',\n    contexts: ['browser_action'],\n    onclick: function () {\n      extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.tabs.create({\n        url: 'index.html#/settings'\n      });\n    }\n  }); // In dev, open a new tab for easier debugging\n\n  if (true) {\n    extensionizer__WEBPACK_IMPORTED_MODULE_2___default.a.tabs.create({\n      url: 'index.html'\n    });\n  }\n}\n\n//# sourceURL=webpack:///./src/background/main.js?");

/***/ }),

/***/ "./src/background/request.ts":
/*!***********************************!*\
  !*** ./src/background/request.ts ***!
  \***********************************/
/*! exports provided: ExternalRequest */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"ExternalRequest\", function() { return ExternalRequest; });\n/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.error.cause.js */ \"../../../node_modules/core-js/modules/es.error.cause.js\");\n/* harmony import */ var core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_error_cause_js__WEBPACK_IMPORTED_MODULE_0__);\n\n\n/**\n * Handle external requests\n */\nconst Actions = ['ACTIVE_ACCOUNT', 'SIGN', 'SIGN_TX', 'SEND_TX'];\nconst ActionsToEventName = {\n  ACTIVE_ACCOUNT: 'AERGO_ACTIVE_ACCOUNT',\n  SIGN: 'AERGO_SIGN_RESULT',\n  SIGN_TX: 'AERGO_SIGN_TX_RESULT',\n  SEND_TX: 'AERGO_SEND_TX_RESULT'\n};\nvar MsgType;\n\n(function (MsgType) {\n  MsgType[\"Request\"] = \"AERGO_REQUEST\";\n  MsgType[\"Response\"] = \"AERGO_RESPONSE\";\n  MsgType[\"Cancel\"] = \"AERGO_CANCEL\";\n})(MsgType || (MsgType = {}));\n\nclass ExternalRequest {\n  constructor(port, action, data) {\n    this.port = port;\n    this.action = action;\n    this.data = data;\n    this.origin = port.sender.origin;\n  }\n\n  sendSuccess(result) {\n    this.port.postMessage({\n      type: MsgType.Response,\n      eventName: ActionsToEventName[this.action],\n      result\n    });\n  }\n\n  sendCancel(result) {\n    this.port.postMessage({\n      type: MsgType.Cancel,\n      eventName: ActionsToEventName[this.action],\n      result\n    });\n  }\n\n  static fromPortMessage(port, msg) {\n    if (msg.type !== MsgType.Request) {\n      throw new Error(`invalid message type ${msg.type}`);\n    }\n\n    const action = msg.action || '';\n\n    if (Actions.indexOf(action) === -1) {\n      throw new Error(`invalid message action type ${action}`);\n    }\n\n    return new ExternalRequest(port, action, msg.data);\n  }\n\n}\n\n//# sourceURL=webpack:///./src/background/request.ts?");

/***/ }),

/***/ "./src/background/tx-scanner.ts":
/*!**************************************!*\
  !*** ./src/background/tx-scanner.ts ***!
  \**************************************/
/*! exports provided: AergoscanTransactionScanner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, \"AergoscanTransactionScanner\", function() { return AergoscanTransactionScanner; });\n/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! core-js/modules/es.promise.js */ \"../../../node_modules/core-js/modules/es.promise.js\");\n/* harmony import */ var core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(core_js_modules_es_promise_js__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _herajs_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @herajs/client */ \"../../../node_modules/@herajs/client/dist/herajs.js\");\n/* harmony import */ var _herajs_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_herajs_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _herajs_wallet__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @herajs/wallet */ \"../../../node_modules/@herajs/wallet/dist/herajs-wallet.iife.js\");\n/* harmony import */ var _herajs_wallet__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_herajs_wallet__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\n/**\n * This is a data source for transactionManager.getAccountTransactions.\n * It uses the Aergoscan API which is experimental and subject to change.\n * It is not recommended to use this data source.\n */\n\nclass AergoscanTransactionScanner {\n  fetchAccountTransactionsAfter() {\n    return next => async function ({\n      account,\n      blockno,\n      limit\n    }) {\n      const chainId = account.data.spec.chainId;\n\n      if (chainId !== 'testnet.aergo.io' && chainId !== 'aergo.io') {\n        return next({\n          account,\n          blockno,\n          limit\n        });\n      }\n\n      let baseUrl;\n\n      if (chainId == 'testnet.aergo.io') {\n        baseUrl = 'https://api.aergoscan.io/testnet';\n      }\n\n      if (chainId == 'aergo.io') {\n        baseUrl = 'https://api.aergoscan.io/main';\n      } // demo 용\n\n\n      baseUrl = 'https://api2-mainnet.aergoscan.io/main';\n      const address = new _herajs_client__WEBPACK_IMPORTED_MODULE_1__[\"Address\"](account.data.spec.address);\n      const q = encodeURIComponent(`(from:${address} OR to:${address}) AND blockno:>${blockno}`);\n      const size = 1000;\n      const offset = 0;\n      const url = `${baseUrl}/transactions?q=${q}&sort=blockno:desc&size=${size}&from=${offset}`;\n\n      try {\n        const response = await fetch(url);\n        const data = await response.json();\n        if (!data.hits) return [];\n        console.log(`[track account] Got ${data.hits.length} (of ${data.total}) txs for ${address} since ${blockno}.`);\n        console.log(data);\n        return data.hits.map(tx => new _herajs_wallet__WEBPACK_IMPORTED_MODULE_2__[\"Transaction\"](tx.hash, {\n          chainId,\n          from: tx.meta.from,\n          to: tx.meta.to,\n          hash: tx.hash,\n          ts: tx.meta.ts,\n          blockhash: '',\n          blockno: tx.meta.blockno,\n          amount: tx.meta.amount,\n          type: tx.meta.type,\n          status: _herajs_wallet__WEBPACK_IMPORTED_MODULE_2__[\"Transaction\"].Status.Confirmed\n        }));\n      } catch (e) {\n        console.log(`[track account] Failed: ${e}`);\n        return [];\n      }\n    };\n  }\n\n  fetchAccountTransactions(wallet) {\n    var _this = this;\n\n    return () => async function (account) {\n      const accountSpec = wallet.accountManager.getCompleteAccountSpec(account.data.spec);\n      const {\n        bestHeight\n      } = await wallet.getClient(accountSpec.chainId).blockchain(); // @ts-ignore\n\n      return _this.fetchAccountTransactionsBefore(wallet)(async function () {\n        return [];\n      })({\n        account,\n        blockno: bestHeight\n      });\n    };\n  }\n\n}\n\n//# sourceURL=webpack:///./src/background/tx-scanner.ts?");

/***/ }),

/***/ "./src/manifest.json":
/*!***************************!*\
  !*** ./src/manifest.json ***!
  \***************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony default export */ __webpack_exports__[\"default\"] = (__webpack_require__.p + \"manifest.json\");\n\n//# sourceURL=webpack:///./src/manifest.json?");

/***/ }),

/***/ 11:
/*!**************************************!*\
  !*** multi ./src/background/main.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

eval("module.exports = __webpack_require__(/*! /Users/seo/aergo-connect-web-v2/packages/@aergo-connect/extension/src/background/main.js */\"./src/background/main.js\");\n\n\n//# sourceURL=webpack:///multi_./src/background/main.js?");

/***/ }),

/***/ 12:
/*!********************!*\
  !*** fs (ignored) ***!
  \********************/
/*! no static exports found */
/***/ (function(module, exports) {

eval("/* (ignored) */\n\n//# sourceURL=webpack:///fs_(ignored)?");

/***/ })

/******/ });